# 基础拓扑学及应用：第一轮压缩试阅版

原著：雷逢春、杨志青、李凤玲。322页。

本版仅对扫描图像作JPEG有损重编码（质量65、4:4:4抽样），不降低图片像素尺寸。正文、LaTeX公式和页面布局保持不变；书签、内部链接及邮箱链接保留。扫描插图仍可能出现JPEG压缩损失，供画质比较试阅。

在解压目录执行（需要XeLaTeX、Python、pypdf、Pillow和原模板所列系统字体）：

```powershell
python tools/build_original_layout.py --pages source/original-layout-latex-math/pages.json --template source/templates/original-layout-latex-math-v1 --bookmark-plan review/retypesetting-note-contact/bookmark-plan.json --output output/topology-original-layout-latex-math.pdf
python tools/compress_download_pdf.py --first-pass
```

压缩结果为output/topology-original-layout-latex-math-compressed-first.pdf，原高清PDF保留。源码保留高清图形素材，压缩包大小不会与轻量PDF同步缩小。原版说明见README-full-edition.md。
