# 基础拓扑学及应用：经典LaTeX数学字体版，字重修订2，附第二页重排说明

322页。正文强调统一黑体；例等小标题以1.1节为基准。逐处修正原书字重差异及两处公式布局，未改写文字、数学内容或编号。检查范围及局限见review/style-audit/report.md。

构建环境：XeLaTeX/TeX Live、Python、pypdf；系统字体SimSun、SimHei、KaiTi、Times New Roman。解压后在根目录执行：

```powershell
python tools/build_original_layout.py --pages source/original-layout-latex-math/pages.json --template source/templates/original-layout-latex-math-v1 --bookmark-plan review/retypesetting-note/bookmark-plan.json --output output/topology-original-layout-latex-math.pdf
```

数学字体为lmodern、CMSY、AMS；原书是扫描件，不能认证与原字体完全相同。当前模板目录保留兼容名称-v1，其profile.json的style_revision=2标识本次修订。旧v1包及原newtxmath版均在主项目独立保留。


本包在v2基础上填入第二页说明，不增页。新书签共157条。说明页检查记录见review/retypesetting-note/audit.json。旧v1/v2源文件包及原newtxmath版仍在主项目独立保存。


本包v4：第二页采用用户确认的说明文字，加入邮箱631396049@qq.com并去掉日期。邮箱为可点击的mailto链接。仅第二页改变；其他321页内容不变。核验见review/retypesetting-note-contact/audit.json。
