# 原书版式模板 v1

基准：用户认可的原书印刷页2—11试排。适用于本书后续同版式正文；其他书使用时先重新测量纸张、版心与字体，不直接套本书坐标。

固定部分：preamble.tex（字体、行距、数学字形、标题宏）与 profile.json（页面与版心参数）。逐页内容：独立 pages.json，保留原书分页和块位置。原始试排及其交付文件保留。

字体：SimSun Scale=1.03、KaiTi Scale=1.05、SimHei、Times New Roman；数学 newtxmath，mathcal 使用 cmsy。正文10bp、基线17.4bp；必须保留 linespread=1，避免 ctex 默认行距再次放大。坐标单位bp，原测量 y_px125 可兼容使用；优先新建 y_bp。纸张515×741bp、偶数页正文x=57、奇数页x=78、宽380bp。

含交换图时构建器自动加载tikz-cd。tikzcd嵌在外层TikZ节点内时，使用 `ampersand replacement=\&`，节点分栏写成 `\&`，避免矩阵分栏符的类别码错误。保留原图节点、箭头和标记。

第三、四章扩展：推论用 `\Cor{编号}`，引理用 `\Lem{编号}`；附有名称的定理、推论、引理用 `\NamedThm{编号}{(名称)}`、`\NamedCor`、`\NamedLem`，保持名称与编号同在原书色框内。这些新增宏不改变原有字体参数或旧页面。章末浅蓝装饰用 `decorations:[{type:chapter-end-band,chapter:3}]`，仅用于对应章末页面；它是近似重建的装饰，不是原扫描页的逐像素复制。

粗体修订：黑体族使用 `AutoFakeBold=1.5`，不把 `BoldFont` 再指向相同的普通SimHei字形。原书强调术语写成 `\BookTerm{术语}`（黑体加粗），段落其余内容仍使用原字体。复用旧TeX时必须核对强调词；旧稿的纯文本不等于原书没有粗体。不要批量加粗所有同名词，只恢复原页指定位置。

运行（在项目根目录）：

```powershell
python tools/build_original_layout.py --pages source/original-layout/pages.json --output output/topology-original-layout.pdf
```

添加 --dry-run 仅校验输入并生成 layout.tex。每页含 printed_page、source_pdf_page、running_header、blocks；页眉必须随章节更新。块 kind 为 body/formula/heading/caption/note/image；文字块含 tex、y_bp，可覆盖 x_bp、width_bp、font_bp、indent_bp。图片 path 相对 pages.json 目录，含 x_bp/y_bp/width_bp/height_bp。装饰条使用 decorations:[{type:note-band,box_bp:[x1,y1,x2,y2]}]，不按页码硬编码。

编译只覆盖该内容目录的 layout.* 和指定输出，失败不会覆盖上次输出。编译后逐页渲染并对照原书；自动检查不代替正文/数学核对。坐标固定不能自动流式延续；新增页必须根据原页分段测量，不能通过缩小字号塞入。字形、字距和少量断行允许保留已知差异。版本调整先重建基准并检查全部受影响页，不静默修改v1参数。

封面与未编号页面：`printed_page:null`，须附唯一`page_id`、`source_pdf_page`、`bookmark_title`和`bookmark_id`；不添加可见页码，正文数字锚点保持不变。整页装帧或空白页可用`kind:retained-page`，唯一图片块引用局部PDF，以pdfpages原样置入。普通文字页仍须使用可编辑文字块。装帧展开图须先裁出独立正封面/封底，不能把折页混入封面；本书裁切入口为normalize_book_covers.py，统一515×741bp。正文宏与字号未变。装饰横线支持decorations中的rule记录。新增前置页面后，链接验证须按页记录定位，禁止硬编码物理页偏移。


整本322页构建后自动按印刷目录生成三级PDF书签，入口为 tools/normalize_original_layout_bookmarks.py；152条目录加4个前置入口，共156项。审计命令：python tools/verify_original_layout_bookmarks.py。保留逐页命名目的地供目录和索引链接使用，页面正文不变。
