"""Reusable original-layout builder. Run --help for inputs and dry-run mode."""
from pathlib import Path
import argparse,json,hashlib,re,shutil,subprocess,os
ROOT=Path(__file__).resolve().parents[1]
TEMPLATE=ROOT/'source/templates/original-layout-v1'

def render(pages,profile,preamble):
    if not pages:raise ValueError('No pages')
    numbers=[p.get('page_id',p['printed_page']) for p in pages]
    if len(numbers)!=len(set(numbers)):raise ValueError('Duplicate printed pages')
    if any(r'\begin{tikzcd}' in b.get('tex','') for p in pages for b in p['blocks']):
        preamble=preamble.replace(r'\begin{document}',r'\usepackage{tikz-cd}'+'\n'+r'\begin{document}')
    if any(p.get('kind')=='retained-page' for p in pages):
        preamble=preamble.replace(r'\begin{document}',r'\usepackage{pdfpages}'+'\n'+r'\begin{document}')
    preamble=preamble.replace('基础拓扑学及应用——原书版式10页试排','基础拓扑学及应用——原书版式重排')
    lines=[preamble]
    for page_index,p in enumerate(pages):
        n=p['printed_page'];page_id=p.get('page_id',n)
        parity=n if n is not None else p['source_pdf_page']
        x=profile['even_x_bp'] if parity%2==0 else profile['odd_x_bp']
        title=p.get('bookmark_title',f'原书第{n}页')
        anchor=p.get('bookmark_id',f'original-page-{n}')
        bookmark=rf'\pdfbookmark[0]{{{title}}}{{{anchor}}}'
        if p.get('kind')=='retained-page':
            assert len(p['blocks'])==1 and p['blocks'][0]['kind']=='image'
            path=p['blocks'][0]['path']
            lines.append(r'\includepdf[pages=1,fitpaper=true,pagebox=mediabox,pagecommand={\thispagestyle{empty}'+bookmark+r'}]{'+path+'}')
            continue
        lines += [r'\null',bookmark,
          r'\begin{tikzpicture}[remember picture,overlay]',r'\begin{scope}[shift={(current page.north west)},x=1bp,y=-1bp]']
        header=p.get('running_header',profile['default_even_header'] if parity%2==0 else profile['default_odd_header'])
        if p.get('kind')=='chapter-opening' or n is None:
            pass
        elif n%2==0:
            lines.append(rf'\node[anchor=north west,inner sep=0,font=\fontsize{{8bp}}{{10bp}}\selectfont] at (44,43) {{{n}\quad {header}}};')
        else:
            lines.append(rf'\node[anchor=north east,inner sep=0,font=\fontsize{{8bp}}{{10bp}}\selectfont] at (474,43) {{{header}\quad {n}}};')
        for d in p.get('decorations',[]):
            if d['type']=='rule':
                lines.append(rf'\draw[{d.get("color","BookLight")},line width={d.get("line_width_bp",.35)}bp] ({d["x1_bp"]},{d["y1_bp"]})--({d["x2_bp"]},{d["y2_bp"]});')
                continue
            if d['type']=='chapter-end-band':
                lines += [r'\shade[left color=white,right color=BookLight!70] (480,0) rectangle (507,733);',r'\begin{scope}\clip (475,0) rectangle (507,250);',r'\node[anchor=north east,text=BookLight!55,font=\fontsize{200bp}{210bp}\selectfont] at (510,25) {'+str(d['chapter'])+'};',r'\end{scope}']
                continue
            if d['type']!='note-band':raise ValueError('Unknown decoration')
            a,b,c,e=d['box_bp']
            lines += [rf'\shade[left color=BookLight!65,right color=white] ({a},{b}) rectangle ({c},{e});',rf'\draw[BookBlue,line width=1.6bp] ({a},{b})--({c},{b});']
        for i,b in enumerate(p['blocks']):
            if b['kind']=='image':
                lines.append(r'\node[anchor=north west,inner sep=0] at ('+f'{b["x_bp"]:.4f},{b["y_bp"]:.4f}'+r') {\includegraphics[width='+f'{b["width_bp"]:.4f}'+r'bp]{'+b['path']+r'}};')
            else:
                xx=x if b.get('x_bp') is None else b['x_bp']
                y=b.get('y_bp',b.get('y_px125',0)*72/125)
                width=b.get('width_bp',profile['text_width_bp'])
                font=b.get('font_bp',profile['body_font_bp'])
                indent=b.get('indent_bp',profile['paragraph_indent_bp'])
                if not (0<=xx<515 and 0<=y<741 and width>0 and xx+width<=515):raise ValueError((n,i,'Invalid box'))
                lines.append(rf'\Block{{p{page_id}-b{i}}}{{{xx}}}{{{y:.4f}}}{{{width}}}{{{font}}}{{{indent}}}{{{b["tex"]}}}')
        lines += [r'\end{scope}\end{tikzpicture}',r'\newpage' if page_index<len(pages)-1 else '']
    lines.append(r'\end{document}')
    return '\n'.join(lines)+'\n'

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--pages',type=Path,required=True,help='Reviewed page-block JSON; image paths relative to this folder')
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--template',type=Path,default=TEMPLATE)
    ap.add_argument('--bookmark-plan',type=Path,default=None)
    ap.add_argument('--minimum-passes',type=int,choices=(1,2),default=2,help='Use 1 only for a position-only rebuild with stable existing aux files')
    ap.add_argument('--dry-run',action='store_true',help='Generate and validate TeX without compiling or replacing PDF')
    args=ap.parse_args();folder=args.pages.resolve().parent
    pages=json.loads(args.pages.read_text(encoding='utf-8'))
    profile=json.loads((args.template/'profile.json').read_text(encoding='utf-8'))
    preamble=(args.template/'preamble.tex').read_text(encoding='utf-8')
    for p in pages:
        for b in p['blocks']:
            if b['kind']=='image' and not (folder/b['path']).is_file():raise FileNotFoundError(b['path'])
    tex=render(pages,profile,preamble);(folder/'layout.tex').write_text(tex,encoding='utf-8')
    if args.dry_run:print(f'Validated {len(pages)} pages; generated {folder / "layout.tex"}');return
    engine=shutil.which('xelatex')
    if not engine:raise FileNotFoundError('XeLaTeX not found')
    for i in range(4):
        r=subprocess.run([engine,'-interaction=nonstopmode','-halt-on-error','-file-line-error','layout.tex'],cwd=folder,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=900)
        (folder/f'layout-pass-{i+1}.log').write_bytes(r.stdout)
        if r.returncode:raise RuntimeError(r.stdout.decode('utf-8',errors='replace')[-4000:])
        current_log=(folder/'layout.log').read_text(encoding='utf-8',errors='replace')
        if i+1>=args.minimum_passes and not re.search(r'Rerun to|Rerun LaTeX',current_log):break
    log=(folder/'layout.log').read_text(encoding='utf-8',errors='replace')
    if re.search(r'Overfull|Missing character|Undefined control sequence|undefined references|multiply defined|Rerun to',log):raise RuntimeError('Layout failed log checks; inspect layout.log')
    from pypdf import PdfReader
    pdf=folder/'layout.pdf';reader=PdfReader(pdf)
    assert len(reader.pages)==len(pages)
    assert all(abs(float(out.mediabox.width)-p.get('page_width_bp',515))<.1 and abs(float(out.mediabox.height)-p.get('page_height_bp',741))<.1 for out,p in zip(reader.pages,pages))
    args.output.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(pdf,args.output)
    if len(pages)==322:
        from normalize_original_layout_bookmarks import apply_outline
        apply_outline(args.output,pages,plan_path=args.bookmark_plan)
    pdf=args.output
    (folder/'layout-build.json').write_text(json.dumps({'template':args.template.name,'pages':len(pages),'sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'visual_review':'pending','warnings':[l for l in log.splitlines() if 'Warning' in l or 'Underfull' in l]},ensure_ascii=False,indent=2),encoding='utf-8')
    print(args.output)
if __name__=='__main__':
    lock=ROOT/'source/templates/original-layout-v1/build.lock'
    with lock.open('x',encoding='utf-8') as f:f.write(str(os.getpid()))
    try:main()
    finally:lock.unlink(missing_ok=True)
