"""Recompress raster images only; preserve editable type, navigation and page geometry."""
from pathlib import Path
import json,hashlib,argparse
from pypdf import PdfReader,PdfWriter
from PIL import Image
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'review/pdf-compression';OUT.mkdir(exist_ok=True)
ap=argparse.ArgumentParser();ap.add_argument('--first-pass',action='store_true');args=ap.parse_args()
src=ROOT/'output/topology-original-layout-latex-math.pdf'
dest=ROOT/('output/topology-original-layout-latex-math-compressed-first.pdf' if args.first_pass else 'output/topology-original-layout-latex-math-light.pdf')
reader=PdfReader(src);writer=PdfWriter();writer.clone_document_from_reader(reader)
seen=set();record=[]
for page in writer.pages:
    for image in page.images:
        ref=image.indirect_reference
        if ref is None or ref.idnum in seen:continue
        seen.add(ref.idnum);im=image.image
        if im.mode=='1':continue
        if 'A' in im.getbands():
            bg=Image.new('RGB',im.size,'white');bg.paste(im,mask=im.getchannel('A'));im=bg
        elif im.mode not in ('RGB','L'):im=im.convert('RGB')
        oldsize=len(image.data);original_pixels=list(im.size)
        if not args.first_pass:im.thumbnail((1000,1400),Image.Resampling.LANCZOS)
        image.replace(im,quality=65 if args.first_pass else 60,optimize=True,subsampling=0 if args.first_pass else 2)
        record.append({'object':ref.idnum,'original_pixels':original_pixels,'pixels':list(im.size),'old_extracted_bytes':oldsize,'new_bytes':len(image.data)})
writer.compress_identical_objects(remove_identicals=True,remove_orphans=True)
writer.write(dest);result=PdfReader(dest)
assert len(result.pages)==len(reader.pages)==322
for p,q in zip(reader.pages,result.pages):
    assert list(p.mediabox)==list(q.mediabox)
    if not args.first_pass:assert p.extract_text()==q.extract_text()
    a=p.get_contents();b=q.get_contents()
    assert (a.get_data() if a else b'')==(b.get_data() if b else b'')
def nav(r):
    def walk(items,depth=0):
        out=[]
        for x in items:
            if isinstance(x,list):out+=walk(x,depth+1)
            else:out.append((depth,x.title,r.get_destination_page_number(x)))
        return out
    names={k:(r.get_destination_page_number(v),str(v.get('/Top')),str(v.get('/Left'))) for k,v in r.named_destinations.items()}
    links=[[str(a.get_object().get('/Dest',a.get_object().get('/A',{}).get('/D',a.get_object().get('/A',{}).get('/URI','')))) for a in p.get('/Annots',[]) if a.get_object().get('/Subtype')=='/Link'] for p in r.pages]
    return walk(r.outline),names,links
assert nav(reader)==nav(result)
report={'original_bytes':src.stat().st_size,'compressed_bytes':dest.stat().st_size,'quality':65 if args.first_pass else 60,'image_max_pixels':None if args.first_pass else [1000,1400],'resolution_unchanged':args.first_pass,'images_recompressed':len(record),'all322_page_content_streams_identical':True,'all322_page_text_and_content_streams_identical':not args.first_pass,'navigation_unchanged':True,'original_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'images':record}
(OUT/('first-audit.json' if args.first_pass else 'audit.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='images'},ensure_ascii=False))
