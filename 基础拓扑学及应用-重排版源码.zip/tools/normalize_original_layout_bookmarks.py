"""Build the PDF outline from the reviewed printed TOC; preserve all page anchors."""
from pathlib import Path
import argparse,json,re
from pypdf import PdfReader,PdfWriter
from pypdf.generic import Fit,NameObject
ROOT=Path(__file__).resolve().parents[1]

def title_text(title):
    for old,new in [(r'\pi','π'),(r'\geqslant','≥'),(r'\times','×')]:
        title=title.replace(old,new)
    title=title.replace('^1','¹').replace('^n','ⁿ').replace('_1','₁').replace('$','')
    return re.sub(r'\s+',' ',title).strip()

def plan_for(pages):
    toc=json.loads((ROOT/'review/frontmatter-toc-entry-list.json').read_text(encoding='utf-8'))
    assert len(toc)==152
    locations={p['printed_page']:i for i,p in enumerate(pages) if p['printed_page'] is not None}
    plan=[]
    frontmatter=[('内容提要',6),('总序',7),('前言',9),('目录',17)]
    # A user-requested editorial note fills the second blank page only in
    # the independent edition; preserve the original edition's outline.
    if pages[1].get('editorial_addition') and pages[1].get('bookmark_title')=='重排说明':
        frontmatter.insert(0,('重排说明',2))
    for title,source in frontmatter:
        plan.append({'title':title,'level':0,'physical_page':source,'top_bp':741.,'source':'frontmatter'})
    for row in toc:
        index=locations[row['target']];p=pages[index];y=0.;block=None
        if p.get('kind')!='retained-page' and not (row['level']==0 and row['title'].startswith(('第','附录'))):
            if row['level']==0:
                hits=[(i,b) for i,b in enumerate(p['blocks']) if b['kind']=='heading']
            else:
                number=re.search(r'[A\d]+(?:\.\d+)+',row['title'])[0]
                hits=[(i,b) for i,b in enumerate(p['blocks']) if b['kind']=='heading'
                    and ('习题' in row['title'])==('习题' in b.get('tex',''))
                    and re.search(r'(?<![\d.])'+re.escape(number)+r'(?![\d.])',b.get('tex',''))]
            assert len(hits)==1,(row,hits)
            block,b=hits[0];y=b.get('y_bp',b.get('y_px125',0)*.576)
        plan.append({'title':title_text(row['title']),'level':row['level'],
            'printed_page':row['target'],'physical_page':index+1,
            'top_bp':round(min(741.,741.-y+18.),4),'heading_block':block,'source':'printed-toc'})
    return plan

def apply_outline(pdf,pages=None,plan_path=None):
    pdf=Path(pdf)
    if pages is None:pages=json.loads((ROOT/'source/original-layout/pages.json').read_text(encoding='utf-8'))
    if len(pages)!=322:return None
    plan=plan_for(pages);reader=PdfReader(pdf);writer=PdfWriter()
    writer.clone_document_from_reader(reader)
    writer.root_object.pop(NameObject('/Outlines'),None)
    parents={}
    for row in plan:
        level=row['level'];assert level==0 or level-1 in parents
        parents[level]=writer.add_outline_item(row['title'],row['physical_page']-1,
            parent=parents.get(level-1) if level else None,
            bold=level==0,fit=Fit.xyz(left=0,top=row['top_bp'],zoom=None),is_open=level==0)
        for key in list(parents):
            if key>level:del parents[key]
    writer.page_mode='/UseOutlines'
    temp=pdf.with_name(pdf.stem+'-bookmarks.tmp.pdf');writer.write(temp)
    result=PdfReader(temp)
    assert len(result.pages)==len(reader.pages)==322
    assert set(result.named_destinations)==set(reader.named_destinations)
    for before,after in zip(reader.pages,result.pages):
        a=before.get_contents();b=after.get_contents()
        assert (a.get_data() if a else b'')==(b.get_data() if b else b'')
        assert list(before.mediabox)==list(after.mediabox)
    temp.replace(pdf)
    (Path(plan_path) if plan_path else ROOT/'review/original-layout-bookmark-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
    return plan

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--pdf',type=Path,default=ROOT/'output/topology-original-layout.pdf')
    args=ap.parse_args();plan=apply_outline(args.pdf)
    print(f'Installed {len(plan)} hierarchical bookmarks from152 TOC entries and4 front-matter entries')
